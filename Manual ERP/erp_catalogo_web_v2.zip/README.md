# ERP Fábrica de Alho — Catálogo Online

Site estático, sem backend e sem dependências externas. Peça comercial: capa,
sumário dos 11 módulos e telas do sistema em molduras de navegador, com legendas
e textos revisados.

## Publicação na web
O arquivo de entrada é `index.html`. Publique a pasta inteira em qualquer
hospedagem que sirva arquivos estáticos.

**Não mova nem renomeie `assets/`**, pois as imagens usam caminhos relativos
(`assets/screens/...`).

## Integração com uma página existente
A opção mais simples é criar um botão na sua página apontando para a URL deste
catálogo. Também é possível incorporar por iframe, se sua plataforma permitir.

## Estrutura
```
index.html              → capa, sumário, 11 seções de módulo, disclaimer, rodapé
assets/screens/*.png    → 28 telas do sistema, já recortadas (sem barra lateral
                           e sem o artefato visual do cabeçalho das capturas
                           originais)
```

## O que mudou nesta revisão
- **Capa** editorial com mockup de tela em moldura de navegador, em vez do
  print único usado antes.
- **Sumário** dos 11 módulos (número, nome, uma linha de valor, contagem de
  telas), como um índice de catálogo impresso.
- Cada tela ganhou uma **moldura de navegador** (pontinhos + caminho tipo
  `Financeiro · Contas a Pagar`), e cada módulo tem uma **tela em destaque**
  maior, com legenda e uma frase de contexto, e as demais como apoio.
- **Textos comerciais reescritos** por módulo — específicos, não genéricos —
  e **legendas em português correto** (antes vinham do nome do arquivo, ex.
  "Rh Quadro Colaboradores").
- **Ordem das telas reorganizada** dentro de cada módulo, seguindo o fluxo de
  uso (ex.: em Cadastros, Produtos → Clientes → Fornecedores → Empresa).
- Reduzido de 34 para **28 telas**: removidas 3 duplicatas de captura e 2
  telas com sobreposição visual de texto (bug do sistema no momento da
  captura, não do catálogo). Se quiser repor esses 6 pontos (Compras,
  Cadastros/Fichas Técnicas, Produção e Financeiro/Painel Executivo) com
  novas capturas, é só recapturar essas telas e eu integro do mesmo jeito.

## Recursos
- Responsivo para desktop, tablet e celular.
- Navegação por módulos.
- Ampliação das telas em lightbox.
- Layout preparado para impressão/PDF.
- Sem frameworks ou chamadas externas.
- Aviso sobre dados demonstrativos, mantido no rodapé.
